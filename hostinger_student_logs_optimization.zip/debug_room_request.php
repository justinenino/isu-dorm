<?php
require_once 'config/database.php';

echo "<h2>Room Request Debug Page</h2>";

try {
    $pdo = getConnection();
    
    // Test 1: Check if bed space columns exist
    echo "<h3>1. Database Column Check</h3>";
    $stmt = $pdo->query("SHOW COLUMNS FROM room_change_requests LIKE 'requested_bed_space_id'");
    $columns_exist = $stmt->rowCount() > 0;
    echo "Bed space columns exist: " . ($columns_exist ? 'Yes' : 'No') . "<br>";
    
    if ($columns_exist) {
        $columns = $stmt->fetchAll();
        foreach ($columns as $column) {
            echo "Column: " . $column['Field'] . " - Type: " . $column['Type'] . "<br>";
        }
    }
    
    // Test 2: Check if there are any recent room change requests
    echo "<h3>2. Recent Room Change Requests</h3>";
    $stmt = $pdo->query("SELECT * FROM room_change_requests ORDER BY requested_at DESC LIMIT 5");
    $requests = $stmt->fetchAll();
    
    if (count($requests) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Student ID</th><th>Requested Room</th><th>Requested Bed Space</th><th>Status</th><th>Created</th></tr>";
        foreach ($requests as $request) {
            echo "<tr>";
            echo "<td>" . $request['id'] . "</td>";
            echo "<td>" . $request['student_id'] . "</td>";
            echo "<td>" . $request['requested_room_id'] . "</td>";
            echo "<td>" . ($request['requested_bed_space_id'] ?? 'NULL') . "</td>";
            echo "<td>" . $request['status'] . "</td>";
            echo "<td>" . $request['requested_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No room change requests found.<br>";
    }
    
    // Test 3: Check if there are any bed spaces
    echo "<h3>3. Available Bed Spaces</h3>";
    $stmt = $pdo->query("SELECT bs.id, bs.bed_number, bs.room_id, r.room_number, bs.is_occupied 
                        FROM bed_spaces bs 
                        JOIN rooms r ON bs.room_id = r.id 
                        ORDER BY bs.room_id, bs.bed_number 
                        LIMIT 10");
    $bed_spaces = $stmt->fetchAll();
    
    if (count($bed_spaces) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Bed Number</th><th>Room</th><th>Occupied</th></tr>";
        foreach ($bed_spaces as $bed) {
            echo "<tr>";
            echo "<td>" . $bed['id'] . "</td>";
            echo "<td>" . $bed['bed_number'] . "</td>";
            echo "<td>" . $bed['room_number'] . "</td>";
            echo "<td>" . ($bed['is_occupied'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No bed spaces found.<br>";
    }
    
    // Test 4: Check error logs
    echo "<h3>4. Recent Error Logs</h3>";
    $log_file = ini_get('error_log');
    if ($log_file && file_exists($log_file)) {
        $logs = file_get_contents($log_file);
        $recent_logs = array_slice(explode("\n", $logs), -20);
        echo "<pre>" . implode("\n", $recent_logs) . "</pre>";
    } else {
        echo "Error log not found or not accessible.<br>";
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "<br>";
}
?>
