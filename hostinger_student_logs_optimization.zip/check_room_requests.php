<?php
require_once 'config/database.php';

echo "<h2>Room Change Requests Diagnostic</h2>";

try {
    $pdo = getConnection();
    
    // Check if bed space columns exist
    echo "<h3>1. Database Schema Check</h3>";
    $stmt = $pdo->query("SHOW COLUMNS FROM room_change_requests");
    $columns = $stmt->fetchAll();
    
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Column Name</th><th>Type</th><th>Null</th><th>Default</th></tr>";
    foreach ($columns as $column) {
        $highlight = '';
        if (in_array($column['Field'], ['requested_bed_space_id', 'current_bed_space_id'])) {
            $highlight = ' style="background-color: #d4edda;"';
        }
        echo "<tr{$highlight}>";
        echo "<td>" . $column['Field'] . "</td>";
        echo "<td>" . $column['Type'] . "</td>";
        echo "<td>" . $column['Null'] . "</td>";
        echo "<td>" . ($column['Default'] ?? 'NULL') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // Check recent room change requests
    echo "<h3>2. Recent Room Change Requests</h3>";
    $stmt = $pdo->query("SELECT 
        rcr.id,
        rcr.student_id,
        rcr.current_room_id,
        rcr.requested_room_id,
        rcr.requested_bed_space_id,
        rcr.current_bed_space_id,
        rcr.reason,
        rcr.status,
        rcr.requested_at,
        s.first_name,
        s.last_name
        FROM room_change_requests rcr
        LEFT JOIN students s ON rcr.student_id = s.id
        ORDER BY rcr.requested_at DESC 
        LIMIT 10");
    $requests = $stmt->fetchAll();
    
    if (count($requests) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Student</th><th>Current Room</th><th>Requested Room</th><th>Requested Bed Space ID</th><th>Current Bed Space ID</th><th>Status</th><th>Created</th></tr>";
        foreach ($requests as $request) {
            echo "<tr>";
            echo "<td>" . $request['id'] . "</td>";
            echo "<td>" . $request['first_name'] . " " . $request['last_name'] . "</td>";
            echo "<td>" . $request['current_room_id'] . "</td>";
            echo "<td>" . $request['requested_room_id'] . "</td>";
            echo "<td>" . ($request['requested_bed_space_id'] ?? 'NULL') . "</td>";
            echo "<td>" . ($request['current_bed_space_id'] ?? 'NULL') . "</td>";
            echo "<td>" . $request['status'] . "</td>";
            echo "<td>" . $request['requested_at'] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No room change requests found.<br>";
    }
    
    // Check if bed spaces exist
    echo "<h3>3. Available Bed Spaces</h3>";
    $stmt = $pdo->query("SELECT bs.id, bs.bed_number, bs.room_id, r.room_number, bs.is_occupied 
                        FROM bed_spaces bs 
                        JOIN rooms r ON bs.room_id = r.id 
                        ORDER BY bs.room_id, bs.bed_number 
                        LIMIT 10");
    $bed_spaces = $stmt->fetchAll();
    
    if (count($bed_spaces) > 0) {
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>Bed Space ID</th><th>Bed Number</th><th>Room</th><th>Occupied</th></tr>";
        foreach ($bed_spaces as $bed) {
            echo "<tr>";
            echo "<td>" . $bed['id'] . "</td>";
            echo "<td>" . $bed['bed_number'] . "</td>";
            echo "<td>" . $bed['room_number'] . "</td>";
            echo "<td>" . ($bed['is_occupied'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No bed spaces found.<br>";
    }
    
    // Test a specific request with bed space lookup
    if (count($requests) > 0) {
        $test_request = $requests[0];
        echo "<h3>4. Test Bed Space Lookup for Request ID: " . $test_request['id'] . "</h3>";
        
        if ($test_request['requested_bed_space_id']) {
            $stmt = $pdo->prepare("SELECT bed_number FROM bed_spaces WHERE id = ?");
            $stmt->execute([$test_request['requested_bed_space_id']]);
            $bed_number = $stmt->fetchColumn();
            
            if ($bed_number) {
                echo "✅ Bed space lookup successful: Bed " . $bed_number . "<br>";
            } else {
                echo "❌ Bed space lookup failed: No bed found with ID " . $test_request['requested_bed_space_id'] . "<br>";
            }
        } else {
            echo "⚠️ No requested_bed_space_id in this request<br>";
        }
    }
    
} catch (Exception $e) {
    echo "❌ Error: " . $e->getMessage() . "<br>";
}
?>
