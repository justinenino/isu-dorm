<?php
// Redirect to login page
header('Location: login.php');
exit();
?>